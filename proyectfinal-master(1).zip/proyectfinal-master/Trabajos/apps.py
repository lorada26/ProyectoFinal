from django.apps import AppConfig


class TrabajosConfig(AppConfig):
    name = 'Trabajos'
